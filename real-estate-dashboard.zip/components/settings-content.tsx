"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Upload, Palette, Type, Save, Eye } from "lucide-react"
import { Badge } from "@/components/ui/badge"

const colorOptions = [
  { name: "Forest Green", value: "#166534", class: "bg-green-800" },
  { name: "Emerald", value: "#059669", class: "bg-emerald-600" },
  { name: "Teal", value: "#0d9488", class: "bg-teal-600" },
  { name: "Blue", value: "#2563eb", class: "bg-blue-600" },
  { name: "Indigo", value: "#4f46e5", class: "bg-indigo-600" },
  { name: "Purple", value: "#7c3aed", class: "bg-purple-600" },
]

const fontOptions = [
  { name: "Inter", value: "inter", preview: "The quick brown fox jumps over the lazy dog" },
  { name: "Roboto", value: "roboto", preview: "The quick brown fox jumps over the lazy dog" },
  { name: "Open Sans", value: "opensans", preview: "The quick brown fox jumps over the lazy dog" },
  { name: "Lato", value: "lato", preview: "The quick brown fox jumps over the lazy dog" },
  { name: "Montserrat", value: "montserrat", preview: "The quick brown fox jumps over the lazy dog" },
]

export function SettingsContent() {
  const [selectedColor, setSelectedColor] = useState("#166534")
  const [selectedFont, setSelectedFont] = useState("inter")
  const [logoFile, setLogoFile] = useState<File | null>(null)

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setLogoFile(file)
    }
  }

  return (
    <div className="flex flex-1 flex-col gap-6 p-6 bg-green-50/30">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-green-900">Settings</h1>
        <p className="text-green-700">Customize your platform appearance and preferences</p>
      </div>

      <Tabs defaultValue="branding" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="branding">Brand Customization</TabsTrigger>
          <TabsTrigger value="account">Account</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
        </TabsList>

        <TabsContent value="branding" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Logo Upload */}
            <Card className="border-green-200 bg-white">
              <CardHeader>
                <CardTitle className="text-green-900 flex items-center gap-2">
                  <Upload className="h-5 w-5" />
                  Logo Upload
                </CardTitle>
                <CardDescription>Upload your company logo to personalize the platform</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border-2 border-dashed border-green-200 rounded-lg p-6 text-center hover:border-green-300 transition-colors">
                  <Upload className="h-8 w-8 text-green-600 mx-auto mb-2" />
                  <p className="text-sm text-green-700 mb-2">
                    {logoFile ? logoFile.name : "Click to upload or drag and drop"}
                  </p>
                  <p className="text-xs text-green-600">PNG, JPG, SVG up to 2MB</p>
                  <Input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" id="logo-upload" />
                  <Label htmlFor="logo-upload" className="cursor-pointer">
                    <Button
                      variant="outline"
                      className="mt-2 border-green-200 text-green-700 hover:bg-green-50 bg-transparent"
                    >
                      Choose File
                    </Button>
                  </Label>
                </div>
                {logoFile && (
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <span className="text-sm text-green-800">{logoFile.name}</span>
                    <Badge className="bg-green-100 text-green-800">Uploaded</Badge>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Color Selection */}
            <Card className="border-green-200 bg-white">
              <CardHeader>
                <CardTitle className="text-green-900 flex items-center gap-2">
                  <Palette className="h-5 w-5" />
                  Primary Color
                </CardTitle>
                <CardDescription>Choose your brand's primary color theme</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-3">
                  {colorOptions.map((color) => (
                    <button
                      key={color.value}
                      onClick={() => setSelectedColor(color.value)}
                      className={`relative p-3 rounded-lg border-2 transition-all hover:scale-105 ${
                        selectedColor === color.value
                          ? "border-green-600 ring-2 ring-green-200"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      <div className={`w-full h-8 rounded ${color.class} mb-2`} />
                      <p className="text-xs font-medium text-gray-700">{color.name}</p>
                      {selectedColor === color.value && (
                        <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-600 rounded-full flex items-center justify-center">
                          <div className="w-2 h-2 bg-white rounded-full" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
                <div className="p-3 bg-green-50 rounded-lg">
                  <p className="text-sm text-green-800">
                    Selected:{" "}
                    <span className="font-medium">{colorOptions.find((c) => c.value === selectedColor)?.name}</span>
                  </p>
                  <p className="text-xs text-green-600 mt-1">Color code: {selectedColor}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Font Selection */}
          <Card className="border-green-200 bg-white">
            <CardHeader>
              <CardTitle className="text-green-900 flex items-center gap-2">
                <Type className="h-5 w-5" />
                Typography
              </CardTitle>
              <CardDescription>Select the font family for your platform</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Select value={selectedFont} onValueChange={setSelectedFont}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a font" />
                </SelectTrigger>
                <SelectContent>
                  {fontOptions.map((font) => (
                    <SelectItem key={font.value} value={font.value}>
                      <div className="flex flex-col">
                        <span className="font-medium">{font.name}</span>
                        <span className="text-xs text-gray-500">{font.preview}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <div className="p-4 bg-green-50 rounded-lg">
                <p className="text-sm text-green-800 mb-2">Preview:</p>
                <div className="space-y-2">
                  <h3 className="text-lg font-bold text-green-900">DealSource Platform</h3>
                  <p className="text-green-700">This is how your text will appear with the selected font.</p>
                  <p className="text-sm text-green-600">Real estate deal sourcing made simple and professional.</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Preview and Save */}
          <Card className="border-green-200 bg-white">
            <CardHeader>
              <CardTitle className="text-green-900 flex items-center gap-2">
                <Eye className="h-5 w-5" />
                Brand Preview
              </CardTitle>
              <CardDescription>See how your customizations will look</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-6 border border-green-200 rounded-lg bg-gradient-to-r from-green-50 to-white">
                <div className="flex items-center gap-3 mb-4">
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center text-white"
                    style={{ backgroundColor: selectedColor }}
                  >
                    <Upload className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-green-900">DealSource</h3>
                    <p className="text-sm text-green-600">Real Estate Platform</p>
                  </div>
                </div>
                <div className="space-y-2">
                  <Button className="text-white" style={{ backgroundColor: selectedColor }}>
                    Primary Button
                  </Button>
                  <p className="text-sm text-green-700">
                    This preview shows how your brand customizations will appear throughout the platform.
                  </p>
                </div>
              </div>

              <div className="flex gap-3">
                <Button className="flex-1 text-white" style={{ backgroundColor: selectedColor }}>
                  <Save className="h-4 w-4 mr-2" />
                  Save Changes
                </Button>
                <Button variant="outline" className="border-green-200 text-green-700 hover:bg-green-50 bg-transparent">
                  Reset to Default
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="account" className="space-y-6">
          <Card className="border-green-200 bg-white">
            <CardHeader>
              <CardTitle className="text-green-900">Account Information</CardTitle>
              <CardDescription>Update your personal and company details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name</Label>
                  <Input id="firstName" defaultValue="John" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input id="lastName" defaultValue="Doe" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" defaultValue="john@dealsource.com" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="company">Company Name</Label>
                <Input id="company" defaultValue="DealSource Properties" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="bio">Bio</Label>
                <Textarea id="bio" placeholder="Tell us about yourself and your real estate business..." />
              </div>
              <Button className="bg-green-600 hover:bg-green-700 text-white">Update Account</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card className="border-green-200 bg-white">
            <CardHeader>
              <CardTitle className="text-green-900">Notification Preferences</CardTitle>
              <CardDescription>Choose what notifications you want to receive</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Email Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Receive email updates about your deals and activities
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Deal Updates</Label>
                    <p className="text-sm text-muted-foreground">Get notified when deal status changes</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>New Messages</Label>
                    <p className="text-sm text-muted-foreground">Notifications for new investor or landlord messages</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Weekly Reports</Label>
                    <p className="text-sm text-muted-foreground">Receive weekly summary of your platform activity</p>
                  </div>
                  <Switch />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integrations" className="space-y-6">
          <Card className="border-green-200 bg-white">
            <CardHeader>
              <CardTitle className="text-green-900">Third-party Integrations</CardTitle>
              <CardDescription>Connect your favorite tools and services</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border border-green-200 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <span className="text-blue-600 font-bold">G</span>
                    </div>
                    <div>
                      <p className="font-medium text-green-900">Google Drive</p>
                      <p className="text-sm text-green-700">Sync documents with Google Drive</p>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    className="border-green-200 text-green-700 hover:bg-green-50 bg-transparent"
                  >
                    Connect
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 border border-green-200 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                      <span className="text-purple-600 font-bold">S</span>
                    </div>
                    <div>
                      <p className="font-medium text-green-900">Slack</p>
                      <p className="text-sm text-green-700">Get notifications in Slack</p>
                    </div>
                  </div>
                  <Badge className="bg-green-100 text-green-800">Connected</Badge>
                </div>

                <div className="flex items-center justify-between p-4 border border-green-200 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                      <span className="text-orange-600 font-bold">Z</span>
                    </div>
                    <div>
                      <p className="font-medium text-green-900">Zapier</p>
                      <p className="text-sm text-green-700">Automate workflows with 5000+ apps</p>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    className="border-green-200 text-green-700 hover:bg-green-50 bg-transparent"
                  >
                    Connect
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
