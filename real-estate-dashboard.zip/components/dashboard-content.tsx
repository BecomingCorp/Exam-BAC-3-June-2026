"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  FileText,
  TrendingUp,
  Users,
  Mail,
  Upload,
  UserPlus,
  FileOutput,
  Clock,
  CheckCircle,
  AlertCircle,
} from "lucide-react"

const summaryCards = [
  {
    title: "Documents Uploaded",
    value: "247",
    change: "+12%",
    changeType: "positive" as const,
    icon: FileText,
  },
  {
    title: "Active Deals",
    value: "18",
    change: "+3",
    changeType: "positive" as const,
    icon: TrendingUp,
  },
  {
    title: "Pending Investor Replies",
    value: "7",
    change: "-2",
    changeType: "negative" as const,
    icon: Users,
  },
  {
    title: "Emails Sent This Week",
    value: "156",
    change: "+24%",
    changeType: "positive" as const,
    icon: Mail,
  },
]

const recentActivity = [
  {
    type: "email",
    title: "Email sent to Investor Group A",
    description: "Property portfolio presentation for downtown development",
    time: "2 hours ago",
    status: "sent",
    icon: Mail,
  },
  {
    type: "chatbot",
    title: "AI Chatbot conversation",
    description: "Landlord inquiry about property valuation process",
    time: "4 hours ago",
    status: "completed",
    icon: CheckCircle,
  },
  {
    type: "pdf",
    title: "PDF Generated",
    description: "Investment summary for 123 Main Street property",
    time: "6 hours ago",
    status: "completed",
    icon: FileOutput,
  },
  {
    type: "document",
    title: "Document uploaded",
    description: "Property inspection report - Riverside Complex",
    time: "1 day ago",
    status: "pending",
    icon: FileText,
  },
]

const quickActions = [
  {
    title: "Upload Document",
    description: "Add new property documents",
    icon: Upload,
    color: "bg-green-600 hover:bg-green-700",
  },
  {
    title: "Create Group",
    description: "Organize investors or landlords",
    icon: UserPlus,
    color: "bg-blue-600 hover:bg-blue-700",
  },
  {
    title: "Generate PDF",
    description: "Create investment summaries",
    icon: FileOutput,
    color: "bg-purple-600 hover:bg-purple-700",
  },
]

export function DashboardContent() {
  return (
    <div className="flex flex-1 flex-col gap-6 p-6 bg-green-50/30">
      {/* Welcome Section */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-green-900">Welcome back, John!</h1>
        <p className="text-green-700">{"Here's what's happening with your real estate deals today."}</p>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {summaryCards.map((card) => (
          <Card key={card.title} className="border-green-200 bg-white shadow-sm hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-green-800">{card.title}</CardTitle>
              <card.icon className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-900">{card.value}</div>
              <p className="text-xs text-muted-foreground">
                <span className={card.changeType === "positive" ? "text-green-600" : "text-red-600"}>
                  {card.change}
                </span>{" "}
                from last month
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Recent Activity */}
        <Card className="border-green-200 bg-white shadow-sm hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle className="text-green-900">Recent Activity</CardTitle>
            <CardDescription>Your latest actions and updates</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div
                key={index}
                className="flex items-start space-x-3 p-3 rounded-lg hover:bg-green-50 transition-colors"
              >
                <div className="flex-shrink-0">
                  {activity.status === "completed" ? (
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  ) : activity.status === "pending" ? (
                    <Clock className="h-5 w-5 text-yellow-600" />
                  ) : (
                    <activity.icon className="h-5 w-5 text-green-600" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-green-900">{activity.title}</p>
                  <p className="text-sm text-green-700">{activity.description}</p>
                  <p className="text-xs text-green-600 mt-1">{activity.time}</p>
                </div>
                <Badge
                  variant={
                    activity.status === "completed"
                      ? "default"
                      : activity.status === "pending"
                        ? "secondary"
                        : "outline"
                  }
                  className={activity.status === "completed" ? "bg-green-100 text-green-800" : ""}
                >
                  {activity.status}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card className="border-green-200 bg-white shadow-sm hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle className="text-green-900">Quick Actions</CardTitle>
            <CardDescription>Common tasks to get you started</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {quickActions.map((action, index) => (
              <Button
                key={index}
                className={`w-full justify-start h-auto p-4 ${action.color} text-white`}
                variant="default"
              >
                <action.icon className="h-5 w-5 mr-3" />
                <div className="text-left">
                  <div className="font-medium">{action.title}</div>
                  <div className="text-sm opacity-90">{action.description}</div>
                </div>
              </Button>
            ))}

            <div className="pt-4 border-t border-green-200">
              <Button
                variant="outline"
                className="w-full border-green-200 text-green-700 hover:bg-green-50 bg-transparent"
              >
                View All Features
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Additional Dashboard Widgets */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card className="border-green-200 bg-white shadow-sm hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle className="text-green-900">Deal Pipeline</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-green-700">Prospecting</span>
                <Badge className="bg-blue-100 text-blue-800">12</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-green-700">Under Review</span>
                <Badge className="bg-yellow-100 text-yellow-800">8</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-green-700">Negotiating</span>
                <Badge className="bg-orange-100 text-orange-800">5</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-green-700">Closed</span>
                <Badge className="bg-green-100 text-green-800">23</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-200 bg-white shadow-sm hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle className="text-green-900">Top Investors</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-xs font-medium text-green-700">AB</span>
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-green-900">Alpha Properties</p>
                  <p className="text-xs text-green-600">5 active deals</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-xs font-medium text-green-700">BC</span>
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-green-900">Beta Capital</p>
                  <p className="text-xs text-green-600">3 active deals</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-xs font-medium text-green-700">GI</span>
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-green-900">Gamma Investments</p>
                  <p className="text-xs text-green-600">2 active deals</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-200 bg-white shadow-sm hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle className="text-green-900">System Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-green-700">Email Service</span>
                <Badge className="bg-green-100 text-green-800">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Online
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-green-700">AI Chatbot</span>
                <Badge className="bg-green-100 text-green-800">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Online
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-green-700">PDF Generator</span>
                <Badge className="bg-green-100 text-green-800">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Online
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-green-700">Document Storage</span>
                <Badge className="bg-yellow-100 text-yellow-800">
                  <AlertCircle className="w-3 h-3 mr-1" />
                  Maintenance
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
