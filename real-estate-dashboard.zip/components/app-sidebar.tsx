"use client"

import * as React from "react"
import { LayoutDashboard, FileText, Bot, FileOutput, Mail, Users, Settings } from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
} from "@/components/ui/sidebar"

const navigationItems = [
  {
    title: "Dashboard",
    url: "/",
    icon: LayoutDashboard,
  },
  {
    title: "Documents",
    url: "/documents",
    icon: FileText,
  },
  {
    title: "AI Chatbot",
    url: "/chatbot",
    icon: Bot,
  },
  {
    title: "PDF Generator",
    url: "/pdf-generator",
    icon: FileOutput,
  },
  {
    title: "Email Automation",
    url: "/email-automation",
    icon: Mail,
  },
  {
    title: "Groups",
    url: "/groups",
    icon: Users,
  },
  {
    title: "Settings",
    url: "/settings",
    icon: Settings,
  },
]

export function AppSidebar() {
  const [currentPath, setCurrentPath] = React.useState("/")

  React.useEffect(() => {
    setCurrentPath(window.location.pathname)
  }, [])

  return (
    <Sidebar className="border-r border-green-100 bg-green-600">
      <SidebarHeader className="border-b border-green-100 p-6 bg-green-600">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg overflow-hidden">
            <img src="/logo-new.png" alt="DealSource Logo" className="h-full w-full object-cover rounded-lg" />
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-semibold text-white">DealSource</span>
            <span className="text-sm text-green-100">Real Estate Platform</span>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent className="bg-green-600">
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {navigationItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={currentPath === item.url}
                    className="data-[active=true]:bg-green-700 data-[active=true]:text-white data-[active=true]:border-r-2 data-[active=true]:border-green-200 hover:bg-green-700 hover:text-white text-green-100"
                  >
                    <a href={item.url} className="flex items-center gap-3 px-3 py-2">
                      <item.icon className="h-5 w-5" />
                      <span className="font-medium">{item.title}</span>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarRail />
    </Sidebar>
  )
}
