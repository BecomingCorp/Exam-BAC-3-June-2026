import "@/styles/globals.css" // Import globals.css at the top of the file
import { DashboardContent } from "@/components/dashboard-content"
import { AppSidebar } from "@/components/app-sidebar"
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar"
import { DashboardHeader } from "@/components/dashboard-header"
import { ThemeProvider } from "@/components/theme-provider"

export default function DashboardPage() {
  return (
    <ThemeProvider defaultTheme="dark" storageKey="dashboard-theme">
      <SidebarProvider defaultOpen={true}>
        <AppSidebar />
        <SidebarInset>
          <DashboardHeader />
          <DashboardContent />
        </SidebarInset>
      </SidebarProvider>
    </ThemeProvider>
  )
}

export const metadata = {
      generator: 'v0.dev'
    };
